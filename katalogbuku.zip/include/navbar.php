<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<a class="navbar-brand" href="index.php">Katalog Buku</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navMenu" aria-controls="navMenu"
		aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navMenu">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="dashboard.php">Dashboard</a>
			</li>
		</ul>
		<div class="form-inline my-2 my-lg-0">

			<a href="register.php" class="btn btn-light mx-1">Register</a>

			<a href="login.php" class="btn btn-dark mx-1">Login</a>
			<a href="proses/logout.php" class="btn btn-dark mx-1">Logout</a>
		</div>
	</div>
</nav>