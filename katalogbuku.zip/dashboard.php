<?php include('include/head.php') ?>
<?php include('include/navbar.php') ?>

<div class="container">
	<div class="row mt-5">
		<div class="col">
			<a href="tambah.php" class="btn btn-primary float-right">Tambah Data Buku</a>
		</div>
	</div>
	<div class="row justify-content-lg-center mt-4">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title mb-4">Daftar Data Buku</h5>
					<!-- tabel daftar buku -->
					<table class="table table-hover table-responsive-md">
						<thead>
							<tr>
								<th scope="col">No.</th>
								<th scope="col">Sampul</th>
								<th scope="col">Judul</th>
								<th scope="col">Pengarang</th>
								<th scope="col">Penerbit</th>
								<th scope="col">Tahun</th>
								<th scope="col">Opsi</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row">1</th>
								<td>NULL</td>
								<td>NULL</td>
								<td>NULL</td>
								<td>NULL</td>
								<td>NULL</td>
								<td>
									<a href="ubah.php" class="btn btn-success">Ubah</a>
									<a href="proses/delete.php" class="btn btn-danger float-right">Hapus</a>
								</td>
							</tr>
						</tbody>
					</table>
					<!-- end tabel -->
				</div>
			</div>
		</div>
	</div>
</div>

<?php include('include/foot.php') ?>